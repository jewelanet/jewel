package com.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public MyServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			int id=Integer.parseInt(request.getParameter("n1"));
			String name=request.getParameter("n2");
			String english=request.getParameter("n3");
			String maths=request.getParameter("n4");
			String physics=request.getParameter("n5");
			String chemistry=request.getParameter("n6");
			
			Connection cn;
			Statement smt;
			ResultSet rs;
			
			try {
				System.out.println("colling");
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				System.out.println("colling");
				
				
				//Step2=Getting connection using DriverManager Class
				cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
				System.out.println("colling");
												
								
				
				//Step3=Creating Statement
				smt= cn.createStatement();
				System.out.println("colling");
				
				//Step4=Execute Query
				//String query="create table employee(eid int,name String)";
				
				//smt.executeUpdate(query);
				
				String insertQuery="insert into marksheet values('"+id+"','"+name+"','"+english+"','"+maths+"','"+physics+"','"+chemistry+"')";
				smt.executeUpdate(insertQuery);
				
				out.println("Data ssaved in database");

				
				smt.close();
				cn.close();
				
			} catch (Exception e) {
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
