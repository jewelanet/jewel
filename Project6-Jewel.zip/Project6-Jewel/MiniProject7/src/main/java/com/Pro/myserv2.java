package com.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class myserv2
 */
public class myserv2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myserv2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Connection cn;
		Statement smt;
		ResultSet rs=null;
		
		try {
			System.out.println("colling");
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("colling");
			
			
			//Step2=Getting connection using DriverManager Class
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			System.out.println("colling");
											
							
			
			//Step3=Creating Statement
			smt= cn.createStatement();
			
			
			//String showQuery="select * from st";
			//smt.executeUpdate(showQuery);
			
			rs=smt.executeQuery("select * from st");
			
			out.println("<center>");
			out.print("Student Grade Card");
			
			out.print("<table border=1>");
			while(rs.next())
			{
				
				System.out.println("Showing Details!!");
			//out.println(+" "+);
					out.println("<tr><td>"+rs.getInt("id")+"</td><td>"+rs.getString("name")+"</td><td>"+rs.getInt("physics")+"</td><td>"+rs.getInt("chemistry")+"</td><td>"+rs.getInt("maths")+"</td><td>"+rs.getInt("english")+"</td></tr>");
			}
			out.println("</table>");
			out.println("</center>");

			
			
			
			System.out.println("Showing Details!!");

			
			smt.close();
			cn.close();
			
		} catch (Exception e) {
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
