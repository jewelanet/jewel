package com.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class myserv1
 */
public class myserv1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myserv1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String n1=request.getParameter("n1");
		String n2=request.getParameter("n2");
		String n3=request.getParameter("n3");
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		try {
			System.out.println("colling");
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("colling");
			
			
			//Step2=Getting connection using DriverManager Class
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			System.out.println("colling");
											
							
			
			//Step3=Creating Statement
			smt= cn.createStatement();
			System.out.println("colling");
			
			//Step4=Execute Query
			//String query="create table employee(eid int,name String)";
			
			//smt.executeUpdate(query);
			rs=smt.executeQuery("select * from marksheet");
			
			
			String updateQuery="update marksheet set name='"+n3+"' where id='"+n1+"'";
			smt.executeUpdate(updateQuery);
		
			
			
			System.out.println("Table is Updated");

			
			smt.close();
			cn.close();
			
		} catch (Exception e) {
			
		}
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
