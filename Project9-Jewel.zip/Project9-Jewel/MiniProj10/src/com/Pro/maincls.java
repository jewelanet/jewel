package com.Pro;

public class maincls {
String name;
int id;
String location;

public maincls(String name, int id, String location) {
	this.name=name;
	this.id=id;
	this.location=location;
}

public String show()
{
	return "("+name+","+id+","+location+")";
}

}
