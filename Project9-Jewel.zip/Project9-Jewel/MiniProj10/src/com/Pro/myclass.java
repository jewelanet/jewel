package com.Pro;

import java.util.ArrayList;
import java.util.Iterator;

public class myclass {

	public static void main(String[] args) {
		ArrayList<maincls> al=new ArrayList();
		maincls m=new maincls("Jewel",1,"Bangalore");
		maincls m1=new maincls("Joel",2,"Calicut");
		maincls m2=new maincls("Asha",3,"Mysore");
		maincls m3=new maincls("Karan",4,"Bangalore");
		
		al.add(m);
		al.add(m1);
		al.add(m2);
		al.add(m3);
		
		System.out.println("____Showing all the Records_____");
		Iterator it=al.iterator();
		
		for(maincls ss:al) {
			System.out.println(ss.id+" "+ ss.name+" "+ ss.location);
		}

	}

}
