package com.Pro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class mycls {
	
	@RequestMapping("/mycls")
	public ModelAndView Add(HttpServletRequest request,HttpServletResponse response)
	{
		String em=request.getParameter("t1");
		String pw=request.getParameter("t2");
		
		
		
		ModelAndView mv=new ModelAndView();
		if("jewel@gmail.com".equals(em) && "1234".equals(pw))
		{
			mv.setViewName("success.jsp");
		}
		else
		{
			mv.setViewName("error.jsp");
		}
		
		//mv.addObject("sum",k);
		
		return mv;
	}
}
